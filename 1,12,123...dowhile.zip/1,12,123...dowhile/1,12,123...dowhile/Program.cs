﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_12_123._._.dowhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 10;
            do
            {
                Console.WriteLine(i);
                i++;
            }
            while (i < 0);
            Console.WriteLine("for loop terminates....");
            Console.ReadLine();

        }
    }
}
