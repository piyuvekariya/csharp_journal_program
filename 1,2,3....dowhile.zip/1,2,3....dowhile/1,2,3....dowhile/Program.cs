﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_2_3._._._.dowhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            do
            {
                Console.Write(i);
                i++;
            }
            while (i < 10);
            Console.Read();
        }
    }
}
