﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace rectangle_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, l, b;
            Console.WriteLine("enter length:");
            l = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter width:");
            b = Convert.ToInt32(Console.ReadLine());
            a = l * b;
            Console.WriteLine("the area of rectangle:{0}", a);
            Console.ReadLine();
        }
    }
}
