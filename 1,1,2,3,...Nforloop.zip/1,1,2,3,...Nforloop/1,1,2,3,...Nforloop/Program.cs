﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_1_2_3_._._.Nforloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int prv = 0, pre =1 , trm, i, n;
            Console.Write("\n\n");
            Console.Write("inpute number of terms to be display:");
            n = Convert.ToInt32(Console.ReadLine());
            Console.Write("{1}*{N},prv pre");
                for(i=3;i<=n;i++)
                {
                    trm=prv*pre;
                    Console.Write("{N}",trm);
                    prv=pre;
                    pre=trm;
                }
            Console.Write("\n");
            Console.ReadLine();

        }
    }
}
