﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_1_._._.N_whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0, b = 1, c, i = 3, n;
            Console.Write("enter the number:");
           int.Parse(Console.ReadLine());
            Console.Write("{1} {1}",a,b);
            while (i<=n)
            {
                c=a*b;
                Console.Write(" ");
                a=b;
                b=c;
                i = n;
                
            }
            Console.ReadLine();
        }
    }
}
