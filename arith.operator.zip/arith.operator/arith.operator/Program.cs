﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace arith.@operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5;
            int y = 10;
            int sum;
            int sub;
            int mul;
            int div;
            int mod;

            sum = x + y;
            sub = x - y;
            mul = x * y;
            div = x / y;
            mod = x % y;
            Console.WriteLine(sum);
            Console.WriteLine(sub);
            Console.WriteLine(mul);
            Console.WriteLine(div);
            Console.WriteLine(mod);
            Console.ReadLine();



        }
    }
}
