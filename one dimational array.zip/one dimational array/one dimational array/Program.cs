﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace one_dimational_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a;
            Console.WriteLine("enter the size of array");
            int p=int.Parse(Console.ReadLine());
            a=new int[p];
            for(int i=0; i<a.Length; i++)
            {
                Console.WriteLine("enter value of{0}:",i);
                a[i]=int.Parse(Console.ReadLine());
            }
            Console.WriteLine("array is created &value is stored in");
            for(int i=0; i<a.Length; i++)
            {
                Console.WriteLine("the a{0} value is:{1}",i,a[i]);
            }

            Console.ReadLine();
         }
    }
}
