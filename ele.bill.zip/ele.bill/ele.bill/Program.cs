﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ele.bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int Unit, U;
            double umt;
            Console.WriteLine("enter total unit");
            Unit = Convert.ToInt32(Console.ReadLine());
            U = Unit / 100;
            switch(U)
            {
                case 0:
                case 1:
                Console.WriteLine("payable amount="+(Unit*10));
                break;
                case 3:
                Console.WriteLine("payable amount="+((10*100)+(100*15)+(Unit-200)*20));
                break;
                default:
                Console.WriteLine("payable amount="+((10*100)+(100*15)+(100+20)+(Unit-300)+25));
                break;
            }
            Console.Read();
        }
    }
}
