﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_12_123._._._.forloop
{
    class Program
    {
        static void Main(string[] args)
        {
             int i,j,rows;
   
	Console.Write("\n\n");
    Console.Write("Display the pattern as right angle triangle using number:\n");
	   Console.Write("Input number of rows : ");
   rows= Convert.ToInt32(Console.ReadLine());   
   for(i=1;i<=rows;i++)
   {
	for(j=1;j<=i;j++)
	   Console.Write("{0}",j);
	Console.Write("\n");
   }
  }
}

        }
   
