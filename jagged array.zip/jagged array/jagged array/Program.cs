﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace jagged_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] a = new int[3][];
            a[0] = new int[2] { 1, 2 };
            a[1] = new int[3] { 3, 4,5 };
            a[2] = new int[4] { 6,7, 8,9};
            for (int i = 0; i < 3; i++);
            {
                for (int j=0; j<a[i]:length; j++)
                {
                    Console.WriteLine("enter value of [{0},{1}],{2}",i,j,a[i][j]);
                }
                Console.ReadLine();
            }

        }
    }
 }

