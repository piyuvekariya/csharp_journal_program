﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_12_123._._._.whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (i <= 5; i++);
            {
                Console.WriteLine(i);
            }
                { Console.WriteLine("For Loop terminates....");
                i++;
                Console.ReadLine();
            }
        }
    }
}
